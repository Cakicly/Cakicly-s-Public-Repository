package com.karalyst.test;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class ServerTest {

    @RequestMapping("/formResponse")
    public static String formResponse(String username,String password) {
        System.out.println(username);
        System.out.println(password);
        return "OK;PassWordToSHA256:" + EncryptSHA256.getSha256(password);
    }

}

class EncryptSHA256 {

    public static String getSha256(String input) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(input.getBytes());
            byte[] hashValue = messageDigest.digest();
            return hashToString(hashValue);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String hashToString(byte[] hashValue) {
        StringBuilder sb = new StringBuilder();
        for (byte b : hashValue) {
            sb.append(String.format("%x",b));
        }
        return sb.toString();
    }

}